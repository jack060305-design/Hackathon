"""
Florida Disaster Risk Prediction Platform
Main entry point for Streamlit app
"""

import streamlit as st
import requests
import os
from datetime import datetime

from county_data import fetch_county_names
from pages import map as map_page
from pages import chatbot as chatbot_page
from pages import ocean_tracker as ocean_tracker_page

API_URL = os.getenv("API_URL", "http://localhost:8000")

# Sidebar + Quick Stats: single list (label, info URL)
DATA_SOURCES: list[tuple[str, str]] = [
    ("USGS Earthquakes", "https://earthquake.usgs.gov/"),
    ("NOAA Hurricanes", "https://www.nhc.noaa.gov/"),
    ("NWS Weather Data", "https://www.weather.gov/"),
    ("NCEP GFS (NOMADS)", "https://nomads.ncep.noaa.gov/"),
    ("FDEM (Florida Disaster)", "https://www.floridadisaster.org/"),
]

st.set_page_config(
    page_title="Florida Disaster AI",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded"
)


@st.cache_data(ttl=3600)
def _fetch_county_list(api_base: str) -> list:
    return fetch_county_names(api_base)


def show_home():
    st.subheader("🏠 Welcome to Florida Disaster Risk Platform")

    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("""
        ### 🌟 AI-Powered Early Warning System

        Our platform uses machine learning to predict disaster risks across Florida counties.

        **Key Features:**
        - 🗺️ **Real-time Risk Maps** - Visualize risk levels across Florida
        - 🤖 **AI Predictions** - ML-based risk assessment
        - 💬 **Smart Assistant** - Get personalized safety advice
        - 📡 **Live Data** - USGS, NOAA, NWS, NCEP GFS (NOMADS), and FDEM

        **How It Works:**
        1. Select a Florida county
        2. Enter current weather conditions
        3. Get instant risk prediction
        4. Receive personalized recommendations
        """)

    with col2:
        st.markdown("### 📊 Quick Stats")

        n_counties = len(_fetch_county_list(API_URL))
        st.metric("Florida Counties", n_counties)

        # Matches backend florida_counties evacuation tiers (coastal A/B, inland C)
        st.metric("Risk Zones", 3, "Evacuation tiers (A / B / C)")

        st.metric(
            "Data Sources",
            len(DATA_SOURCES),
            "USGS · NOAA · NWS · NCEP · FDEM",
        )

    st.divider()
    st.subheader("🔮 Quick Risk Assessment")

    col1, col2, col3 = st.columns(3)

    with col1:
        county = st.selectbox("County", _fetch_county_list(API_URL))

    with col2:
        wind = st.slider("Wind Speed (mph)", 0, 150, 50)

    with col3:
        rain = st.slider("Rainfall (inches)", 0.0, 20.0, 3.0)

    if st.button("🔮 Predict Risk", type="primary"):
        with st.spinner("Analyzing risk factors..."):
            try:
                response = requests.post(
                    f"{API_URL}/api/prediction/predict",
                    json={
                        "county": county,
                        "wind_speed": wind,
                        "rainfall": rain,
                        "population_density": "Medium"
                    },
                    timeout=5
                )

                if response.status_code == 200:
                    result = response.json()
                    risk_score = result["risk_score"] * 100

                    if risk_score >= 70:
                        st.error(f"🔴 **HIGH RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-high">⚠️ Immediate action required</div>', unsafe_allow_html=True)
                    elif risk_score >= 40:
                        st.warning(f"🟡 **MEDIUM RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-medium">📋 Prepare now</div>', unsafe_allow_html=True)
                    else:
                        st.success(f"🟢 **LOW RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-low">✅ Stay informed</div>', unsafe_allow_html=True)

                    st.markdown("**📋 Recommendations:**")
                    for rec in result["recommendations"]:
                        st.write(f"- {rec}")
                else:
                    st.error("Unable to get prediction from backend")
            except Exception as e:
                st.error(f"Connection error: {e}")
                st.info("Make sure backend is running: `python -m uvicorn app.main:app --reload --port 8000`")

    st.divider()
    st.caption("🚨 **EMERGENCY:** Call 911 immediately if you are in danger")


st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1e3c72, #2a5298);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .risk-high {
        background-color: #ff6b6b;
        padding: 1rem;
        border-radius: 10px;
        color: white;
    }
    .risk-medium {
        background-color: #ffd93d;
        padding: 1rem;
        border-radius: 10px;
        color: #333;
    }
    .risk-low {
        background-color: #6bcf7f;
        padding: 1rem;
        border-radius: 10px;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="main-header">
    <h1>🌊 Florida Disaster Risk Prediction</h1>
    <p>AI-powered early warning system for Florida communities</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("### 🧭 Navigation")
    page = st.radio(
        "Select Page",
        ["🏠 Home", "🗺️ Risk Map", "🌊 Ocean Tracker", "💬 AI Assistant"],
        label_visibility="collapsed"
    )

    st.divider()

    st.markdown("### 🔌 System Status")
    try:
        response = requests.get(f"{API_URL}/health", timeout=2)
        if response.status_code == 200:
            st.success("✅ Backend Connected")
            st.caption(f"API: {API_URL}")
        else:
            st.warning("⚠️ Backend Issue")
    except Exception:
        st.error("❌ Backend Disconnected")
        st.caption("Make sure backend is running at localhost:8000")

    st.divider()

    st.markdown("### 📡 Data Sources")
    for label, url in DATA_SOURCES:
        st.markdown(f"- [{label}]({url})")

    st.divider()

    st.markdown("### ⏰ Update Schedule")
    st.markdown("**Every 7 days**")
    st.caption(f"Last update: {datetime.now().strftime('%Y-%m-%d')}")

if page == "🏠 Home":
    show_home()
elif page == "🗺️ Risk Map":
    map_page.show()
elif page == "🌊 Ocean Tracker":
    ocean_tracker_page.show()
elif page == "💬 AI Assistant":
    chatbot_page.show()
