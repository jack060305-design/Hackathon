import hashlib
import os

import folium
import requests
import streamlit as st
from streamlit_folium import folium_static

from county_data import get_county_map_points_offline

API_URL = os.getenv("API_URL", "http://localhost:8000")


def _demo_risk(name: str) -> float:
    """Deterministic 0.15–0.92 demo risk from county name (replace with model later)."""
    h = hashlib.sha256(name.encode()).hexdigest()
    return 0.15 + (int(h[:8], 16) % 7700) / 10000.0


def show():
    st.subheader("Florida Risk Map")
    st.markdown("All 67 counties (centroids) — demo risk shading; live USGS / NOAA below.")

    points = get_county_map_points_offline()

    m = folium.Map(
        location=[27.8, -81.5],
        zoom_start=7,
        tiles="OpenStreetMap",
    )

    if not points:
        st.warning(
            "Missing 67-county data. Run export from backend or add "
            "data/florida_county_centroids.json at the repo root."
        )
    else:
        for row in points:
            name = row["name"]
            lat = float(row["lat"])
            lon = float(row["lon"])
            risk = _demo_risk(name)
            if risk >= 0.7:
                color = "red"
                fill_color = "darkred"
            elif risk >= 0.4:
                color = "orange"
                fill_color = "orange"
            else:
                color = "green"
                fill_color = "green"

            folium.CircleMarker(
                location=[lat, lon],
                radius=max(4, risk * 18),
                popup=(
                    f"<b>{name}</b><br>"
                    f"Demo risk: {risk*100:.0f}%<br>"
                    f"Evac. zone: {row.get('evacuation_zone', '?')}"
                ),
                color=color,
                fill=True,
                fillColor=fill_color,
                fillOpacity=0.55,
                tooltip=f"{name}: {risk*100:.0f}%",
            ).add_to(m)

    legend_html = """
    <div style="position: fixed; bottom: 50px; left: 50px; z-index: 1000;
                background: white; padding: 12px; border-radius: 8px;
                border: 2px solid #ccc; box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                font-family: Arial; font-size: 14px;">
    <b>Risk (demo)</b><br>
    <span style="color:red">●</span> High (70–100%)<br>
    <span style="color:orange">●</span> Medium (40–70%)<br>
    <span style="color:green">●</span> Low (0–40%)<br>
    <hr style="margin: 5px 0;">
    <span>67 county centroids</span>
    </div>
    """
    m.get_root().html.add_child(folium.Element(legend_html))

    folium_static(m, width=800, height=600)

    st.divider()
    st.subheader("Real-time Data from Backend")

    col1, col2 = st.columns(2)

    with col1:
        with st.expander("USGS Earthquake Data"):
            try:
                response = requests.get(f"{API_URL}/api/disasters/usgs?limit=3", timeout=5)
                if response.status_code == 200:
                    events = response.json()
                    if events:
                        for eq in events:
                            mag = eq.get("magnitude", "N/A")
                            location = eq.get("location", "Unknown")
                            st.write(f"• **Magnitude {mag}** — {location}")
                    else:
                        st.write("No recent earthquakes")
                else:
                    st.write("Unable to fetch USGS data")
            except Exception as e:
                st.write(f"Connection error: {e}")

    with col2:
        with st.expander("NOAA Hurricane Data"):
            try:
                response = requests.get(
                    f"{API_URL}/api/disasters/noaa/hurricanes", timeout=5
                )
                if response.status_code == 200:
                    storms = response.json()
                    for storm in storms:
                        name = storm.get("name", "Unknown")
                        category = storm.get("category", "N/A")
                        st.write(f"• **{name}** — Category {category}")
                else:
                    st.write("No active hurricanes")
            except Exception as e:
                st.write(f"Connection error: {e}")
