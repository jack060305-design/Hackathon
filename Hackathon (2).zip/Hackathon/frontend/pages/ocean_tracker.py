"""
Florida Ocean Tracker Page
"""

import os
import streamlit as st
import requests
import pandas as pd

API_URL = os.getenv("API_URL", "http://localhost:8000")


def show():
    st.subheader("Florida Ocean Disaster Tracker")
    st.markdown("Real-time tracking of hurricanes and storms threatening Florida")

    try:
        risk_response = requests.get(f"{API_URL}/api/ocean/coastal-risk", timeout=5)
        if risk_response.status_code == 200:
            risk_data = risk_response.json()

            col1, col2 = st.columns(2)
            with col1:
                risk_color = {
                    "Extreme": "High",
                    "High": "High",
                    "Moderate": "Med",
                    "Low": "Low",
                }.get(risk_data.get("coastal_risk"), "?")
                st.metric(
                    "Florida Coastal Risk",
                    f"{risk_data.get('coastal_risk', 'Unknown')} ({risk_color})",
                )
            with col2:
                st.metric("Active Storms", risk_data.get("status", "—"))

            st.info(risk_data.get("advisory", ""))
    except Exception:
        st.warning("Unable to fetch coastal risk data")

    st.divider()
    st.subheader("Active Storms")

    try:
        storms_response = requests.get(f"{API_URL}/api/ocean/active-storms", timeout=5)
        if storms_response.status_code == 200:
            storms_data = storms_response.json()

            if storms_data.get("storms"):
                for storm in storms_data["storms"]:
                    sid = storm.get("id") or storm.get("name") or "storm"
                    with st.expander(
                        f"{storm.get('name', 'Unnamed')} — Cat {storm.get('category', 'N/A')}"
                    ):
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Wind Speed", f"{storm.get('wind_speed', 'N/A')} mph")
                            st.metric("Pressure", f"{storm.get('pressure', 'N/A')} mb")
                        with col2:
                            st.metric(
                                "Position",
                                f"{storm.get('latitude', 'N/A')}, {storm.get('longitude', 'N/A')}",
                            )

                        if st.button("Predict Florida Impact", key=str(sid)):
                            with st.spinner("Calculating Florida impact..."):
                                impact_response = requests.get(
                                    f"{API_URL}/api/ocean/florida-impact/{sid}",
                                    timeout=5,
                                )
                                if impact_response.status_code == 200:
                                    impact = impact_response.json()

                                    st.markdown("---")
                                    st.subheader("Florida Impact Prediction")

                                    col_a, col_b = st.columns(2)
                                    with col_a:
                                        st.metric(
                                            "Landfall Probability",
                                            f"{impact.get('landfall_probability', 0)}%",
                                        )
                                    with col_b:
                                        st.metric(
                                            "Distance to Florida",
                                            f"{impact.get('distance_to_florida_miles', 0)} miles",
                                        )

                                    st.info(f"Impact zone: {impact.get('impact_zone', '')}")

                                    if impact.get("affected_counties"):
                                        st.subheader("Affected Counties")
                                        df = pd.DataFrame(impact["affected_counties"])
                                        st.dataframe(
                                            df, use_container_width=True, hide_index=True
                                        )

                                    st.subheader("Recommendations")
                                    for rec in impact.get("recommendations", []):
                                        st.write(rec)
            else:
                st.success("No active storms in feed (or season quiet).")
    except Exception as e:
        st.error(f"Unable to fetch storm data: {e}")

    st.divider()
    with st.expander("About Florida hurricane risk"):
        st.markdown(
            """
**Season:** June 1 – November 30

**Resources:** floridadisaster.org · nhc.noaa.gov
            """
        )
