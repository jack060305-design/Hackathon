"""
Florida Ocean Disaster Tracker
Detects hurricanes/storms and predicts land impact
"""

import httpx
import math
from typing import List, Dict
from datetime import datetime

from .florida_counties import evacuation_zone, florida_counties


class FloridaOceanTracker:
    """Track hurricanes and ocean storms threatening Florida"""

    def __init__(self):
        self.nhc_base = "https://www.nhc.noaa.gov"

    async def fetch_active_storms(self) -> List[Dict]:
        """Fetch active storms from NHC index.json"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{self.nhc_base}/index.json",
                    timeout=10.0,
                )
                if response.status_code != 200:
                    return []
                data = response.json()
                raw = data.get("activeStorms") or data.get("active_storms") or []
                storms = []
                for storm in raw:
                    storms.append(
                        {
                            "id": str(
                                storm.get("id")
                                or storm.get("stormId")
                                or storm.get("name", "unknown")
                            ),
                            "name": storm.get("name"),
                            "category": storm.get("category"),
                            "wind_speed": storm.get("windSpeed")
                            or storm.get("wind_speed"),
                            "latitude": storm.get("latitude") or storm.get("lat"),
                            "longitude": storm.get("longitude") or storm.get("lon"),
                            "direction": storm.get("direction")
                            or storm.get("movementDir"),
                            "speed": storm.get("movementSpeed")
                            or storm.get("speed"),
                            "pressure": storm.get("pressure"),
                        }
                    )
                return storms
            except Exception:
                return []

    def calculate_florida_impact(self, storm: Dict) -> Dict:
        """Calculate probability and affected counties"""
        storm_lat = float(storm.get("latitude") or 0)
        storm_lon = float(storm.get("longitude") or 0)
        wind_speed = float(storm.get("wind_speed") or 0)
        direction = float(storm.get("direction") or 0)
        speed = float(storm.get("speed") or 0)

        distance = self._distance_to_florida(storm_lat, storm_lon)

        probability = self._calculate_probability(
            storm_lat, storm_lon, direction, speed, wind_speed, distance
        )

        affected = self._get_affected_counties(
            storm_lat, storm_lon, direction, probability
        )

        impact_zone = self._get_impact_zone(storm_lat, storm_lon, direction)

        return {
            "storm_name": storm.get("name"),
            "category": storm.get("category"),
            "wind_speed": wind_speed,
            "distance_to_florida_miles": round(distance, 1),
            "landfall_probability": probability,
            "impact_zone": impact_zone,
            "affected_counties": affected[:10],
            "recommendations": self._get_recommendations(
                probability, wind_speed, impact_zone
            ),
            "timestamp": datetime.now().isoformat(),
        }

    def _distance_to_florida(self, lat: float, lon: float) -> float:
        florida_lat, florida_lon = 27.8, -81.5
        return self._haversine_distance(lat, lon, florida_lat, florida_lon)

    def _haversine_distance(self, lat1, lon1, lat2, lon2) -> float:
        R = 3959
        lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(
            dlon / 2
        ) ** 2
        c = 2 * math.asin(math.sqrt(a))
        return R * c

    def _calculate_probability(self, lat, lon, direction, speed, wind_speed, distance) -> float:
        prob = 0

        if distance < 100:
            prob += 80
        elif distance < 300:
            prob += 50
        elif distance < 600:
            prob += 25
        else:
            prob += 10

        if self._heading_toward_florida(lat, lon, direction):
            prob += 30
        else:
            prob -= 20

        if wind_speed > 110:
            prob += 15
        elif wind_speed > 74:
            prob += 10

        return min(95, max(0, prob))

    def _heading_toward_florida(self, lat, lon, direction) -> bool:
        if lon > -80:
            return 270 <= direction <= 360
        if lon < -85:
            return 0 <= direction <= 180
        return True

    def _get_affected_counties(self, lat, lon, direction, probability) -> List[Dict]:
        affected = []
        centroids = florida_counties.get_county_centroids()

        for county_name, coords in centroids.items():
            clat = float(coords["lat"])
            clon = float(coords["lon"])
            distance = self._haversine_distance(lat, lon, clat, clon)
            risk = max(0, 100 - (distance / 10)) * (probability / 100)

            if risk > 10:
                affected.append(
                    {
                        "county": county_name,
                        "risk_percentage": round(min(95, risk), 1),
                        "evacuation_zone": evacuation_zone(county_name),
                    }
                )

        affected.sort(key=lambda x: x["risk_percentage"], reverse=True)
        return affected

    def _get_impact_zone(self, lat, lon, direction) -> str:
        if lon > -80:
            return "East Coast (Miami to Jacksonville)"
        if lon < -85:
            return "Gulf Coast (Tampa to Pensacola)"
        return "Keys & South Florida"

    def _get_recommendations(self, probability, wind_speed, impact_zone) -> List[str]:
        recs = []

        if probability > 70:
            recs.append(
                f"HIGH PROBABILITY - {impact_zone} prepare for landfall"
            )
            recs.append("Follow evacuation orders immediately")
        elif probability > 40:
            recs.append(f"MODERATE PROBABILITY - {impact_zone} monitor closely")
            recs.append("Complete emergency preparations")
        else:
            recs.append("LOW PROBABILITY - Continue monitoring")

        if wind_speed > 110:
            recs.append("MAJOR HURRICANE - Prepare for extended power outage")
        elif wind_speed > 74:
            recs.append("HURRICANE FORCE WINDS - Secure property")

        recs.append("Monitor: floridadisaster.org")
        return recs


florida_ocean = FloridaOceanTracker()
