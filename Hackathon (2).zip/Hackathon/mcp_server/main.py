"""
Florida county data MCP server (stdio). Reads repo data/florida_county_centroids.json.
Run from repo root: python -m mcp_server.main
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

_REPO = Path(__file__).resolve().parent.parent
_CENTROIDS_PATH = _REPO / "data" / "florida_county_centroids.json"

# External data references (no secrets; clients fetch directly from these hosts)
NOAA_NOMADS_BASE = "https://nomads.ncep.noaa.gov/"
FLORIDA_DISASTER_SITE = "https://www.floridadisaster.org/"
# Public site may expose JSON under /api; confirm current paths on floridadisaster.org
FLORIDA_DISASTER_API_BASE = "https://www.floridadisaster.org/api"

_BUNDLED_DATA_RESOURCES: list[dict[str, str]] = [
    {
        "id": "county_centroids",
        "name": "Florida county centroids",
        "uri": "florida://counties/centroids.json",
        "description": (
            "Bundled 67 Florida counties with approximate centroid lat/lon for maps and tools."
        ),
    },
]

_EXTERNAL_DATA_SOURCES: list[dict[str, str]] = [
    {
        "id": "noaa_nomads",
        "name": "NOAA NOMADS",
        "title": "NOAA NCEP NOMADS",
        "base_url": NOAA_NOMADS_BASE,
        "description": (
            "Operational NCEP model output (e.g. GFS, NAM, HRRR) and GRIB filter services; "
            "use for forecast grids and time-series aligned with hurricane track planning."
        ),
    },
    {
        "id": "florida_disaster_api",
        "name": "Florida Disaster API",
        "title": "Florida Disaster (Division of Emergency Management)",
        "base_url": FLORIDA_DISASTER_SITE,
        "api_base": FLORIDA_DISASTER_API_BASE,
        "description": (
            "State emergency information; API routes change over time - "
            "use api_base as the starting point and follow official docs or network tab on the site."
        ),
    },
]


def _all_data_resources() -> list[dict[str, str]]:
    """Bundled file resources plus external NOAA / Florida Disaster endpoints (each with name)."""
    return [dict(r) for r in _BUNDLED_DATA_RESOURCES] + [
        dict(r) for r in _EXTERNAL_DATA_SOURCES
    ]

ZONE_A: frozenset[str] = frozenset(
    {
        "Miami-Dade",
        "Broward",
        "Monroe",
        "Collier",
        "Lee",
        "Charlotte",
        "Sarasota",
        "Manatee",
        "Pinellas",
        "Bay",
        "Escambia",
        "Okaloosa",
        "Santa Rosa",
        "Walton",
        "Gulf",
        "Franklin",
        "Taylor",
    }
)
ZONE_B: frozenset[str] = frozenset(
    {
        "Palm Beach",
        "Martin",
        "St. Lucie",
        "Indian River",
        "Brevard",
        "Volusia",
        "Flagler",
        "St. Johns",
        "Duval",
        "Nassau",
        "Citrus",
        "Hernando",
        "Levy",
        "Wakulla",
    }
)


def _evacuation_zone(county: str) -> str:
    if county in ZONE_A:
        return "A"
    if county in ZONE_B:
        return "B"
    return "C"


def _load_centroids() -> dict[str, dict[str, float]]:
    if not _CENTROIDS_PATH.is_file():
        return {}
    return json.loads(_CENTROIDS_PATH.read_text(encoding="utf-8"))


mcp = FastMCP("Florida disaster county data")


@mcp.tool()
def list_florida_counties() -> list[str]:
    """Return all county names from bundled centroids (sorted)."""
    return sorted(_load_centroids().keys())


@mcp.tool()
def get_county_centroids() -> dict[str, dict[str, float]]:
    """County name -> {lat, lon} from data/florida_county_centroids.json."""
    return _load_centroids()


@mcp.tool()
def get_county_map_points() -> list[dict[str, Any]]:
    """All counties with lat, lon, and evacuation_zone (A / B / C)."""
    data = _load_centroids()
    out: list[dict[str, Any]] = []
    for name in sorted(data.keys()):
        c = data[name]
        out.append(
            {
                "name": name,
                "lat": c["lat"],
                "lon": c["lon"],
                "evacuation_zone": _evacuation_zone(name),
            }
        )
    return out


@mcp.resource("florida://counties/centroids.json")
def centroids_resource() -> str:
    """Raw JSON for county centroids (same file as on disk)."""
    if not _CENTROIDS_PATH.is_file():
        return "{}"
    return _CENTROIDS_PATH.read_text(encoding="utf-8")


@mcp.resource("florida://data-sources/noaa-nomads.json")
def resource_noaa_nomads_json() -> str:
    """NOAA NOMADS (nomads.ncep.noaa.gov); metadata for programmatic use."""
    return json.dumps(_EXTERNAL_DATA_SOURCES[0], indent=2) + "\n"


@mcp.resource("florida://data-sources/noaa-nomads.md")
def resource_noaa_nomads_md() -> str:
    """Human-readable notes for NOAA NCEP NOMADS."""
    meta = _EXTERNAL_DATA_SOURCES[0]
    return f"""# {meta["title"]}

- **Name:** {meta["name"]}
- **Base URL:** {NOAA_NOMADS_BASE}
- **Host:** `nomads.ncep.noaa.gov`
- **Role:** Distribution of NCEP operational model data (GRIB subsets, filters, and related guidance).
- **Usage:** Use HTTPS GET to the NOMADS UI or documented filter endpoints; respect NOAA [robots.txt](https://nomads.ncep.noaa.gov/robots.txt) and rate limits.

"""


@mcp.resource("florida://data-sources/floridadisaster-api.json")
def resource_florida_disaster_json() -> str:
    """Florida Disaster API base (floridadisaster.org/api); metadata."""
    return json.dumps(_EXTERNAL_DATA_SOURCES[1], indent=2) + "\n"


@mcp.resource("florida://data-sources/floridadisaster-api.md")
def resource_florida_disaster_md() -> str:
    """Human-readable notes for Florida Disaster public API entrypoint."""
    meta = _EXTERNAL_DATA_SOURCES[1]
    return f"""# {meta["title"]}

- **Name:** {meta["name"]}
- **Site:** {FLORIDA_DISASTER_SITE}
- **API base (typical):** {FLORIDA_DISASTER_API_BASE}
- **Role:** State of Florida emergency management public information; API surface may include alerts, maps, or content feeds.
- **Usage:** Discover current JSON routes from the live site or official documentation; do not assume undocumented paths remain stable.

"""


@mcp.resource("florida://data-sources/catalog.json")
def resource_data_sources_catalog() -> str:
    """All data resources (bundled URIs + external NOAA / Florida Disaster), each with name."""
    return json.dumps(_all_data_resources(), indent=2, ensure_ascii=False) + "\n"


@mcp.tool()
def get_external_data_sources() -> list[dict[str, str]]:
    """
    External NOAA NOMADS (nomads.ncep.noaa.gov) and Florida Disaster API bases
    (floridadisaster.org/api) for forecasts and state emergency data. Each entry includes name.
    """
    return [dict(item) for item in _EXTERNAL_DATA_SOURCES]


@mcp.tool()
def get_data_resources() -> list[dict[str, str]]:
    """Bundled MCP resources and external APIs; every item has id, name, and uri or base_url."""
    return _all_data_resources()


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
