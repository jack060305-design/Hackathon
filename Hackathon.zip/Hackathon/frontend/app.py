"""
Florida Disaster Risk Prediction Platform
Main entry point for Streamlit app
"""

import streamlit as st
import requests
import os
from datetime import datetime

from pages import map as map_page
from pages import chatbot as chatbot_page

API_URL = os.getenv("API_URL", "http://localhost:8000")

st.set_page_config(
    page_title="Florida Disaster AI",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded"
)


def show_home():
    st.subheader("🏠 Welcome to Florida Disaster Risk Platform")

    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("""
        ### 🌟 AI-Powered Early Warning System

        Our platform uses machine learning to predict disaster risks across Florida counties.

        **Key Features:**
        - 🗺️ **Real-time Risk Maps** - Visualize risk levels across Florida
        - 🤖 **AI Predictions** - ML-based risk assessment
        - 💬 **Smart Assistant** - Get personalized safety advice
        - 📡 **Live Data** - USGS, NOAA, and NWS integration

        **How It Works:**
        1. Select a Florida county
        2. Enter current weather conditions
        3. Get instant risk prediction
        4. Receive personalized recommendations
        """)

    with col2:
        st.markdown("### 📊 Quick Stats")

        try:
            response = requests.get(f"{API_URL}/api/prediction/counties", timeout=2)
            if response.status_code == 200:
                data = response.json()
                clist = data.get("counties") or []
                st.metric("Florida Counties", len(clist) if clist else 67)
            else:
                st.metric("Florida Counties", 67)
        except Exception:
            st.metric("Florida Counties", "67", "Monitored")

        st.metric("Risk Zones", "5", "Evacuation zones")
        st.metric("Data Sources", "4", "Real-time")

    st.divider()
    st.subheader("🔮 Quick Risk Assessment")

    col1, col2, col3 = st.columns(3)

    with col1:
        county = st.selectbox(
            "County",
            ["Miami-Dade", "Broward", "Palm Beach", "Hillsborough", "Orange", "Duval"]
        )

    with col2:
        wind = st.slider("Wind Speed (mph)", 0, 150, 50)

    with col3:
        rain = st.slider("Rainfall (inches)", 0.0, 20.0, 3.0)

    if st.button("🔮 Predict Risk", type="primary"):
        with st.spinner("Analyzing risk factors..."):
            try:
                response = requests.post(
                    f"{API_URL}/api/prediction/predict",
                    json={
                        "county": county,
                        "wind_speed": wind,
                        "rainfall": rain,
                        "population_density": "Medium"
                    },
                    timeout=5
                )

                if response.status_code == 200:
                    result = response.json()
                    risk_score = result["risk_score"] * 100

                    if risk_score >= 70:
                        st.error(f"🔴 **HIGH RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-high">⚠️ Immediate action required</div>', unsafe_allow_html=True)
                    elif risk_score >= 40:
                        st.warning(f"🟡 **MEDIUM RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-medium">📋 Prepare now</div>', unsafe_allow_html=True)
                    else:
                        st.success(f"🟢 **LOW RISK** - {risk_score:.0f}%")
                        st.markdown('<div class="risk-low">✅ Stay informed</div>', unsafe_allow_html=True)

                    st.markdown("**📋 Recommendations:**")
                    for rec in result["recommendations"]:
                        st.write(f"- {rec}")
                else:
                    st.error("Unable to get prediction from backend")
            except Exception as e:
                st.error(f"Connection error: {e}")
                st.info("Make sure backend is running: `python -m uvicorn app.main:app --reload --port 8000`")

    st.divider()
    st.caption("🚨 **EMERGENCY:** Call 911 immediately if you are in danger")


st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1e3c72, #2a5298);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .risk-high {
        background-color: #ff6b6b;
        padding: 1rem;
        border-radius: 10px;
        color: white;
    }
    .risk-medium {
        background-color: #ffd93d;
        padding: 1rem;
        border-radius: 10px;
        color: #333;
    }
    .risk-low {
        background-color: #6bcf7f;
        padding: 1rem;
        border-radius: 10px;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="main-header">
    <h1>🌊 Florida Disaster Risk Prediction</h1>
    <p>AI-powered early warning system for Florida communities</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("### 🧭 Navigation")
    page = st.radio(
        "Select Page",
        ["🏠 Home", "🗺️ Risk Map", "💬 AI Assistant"],
        label_visibility="collapsed"
    )

    st.divider()

    st.markdown("### 🔌 System Status")
    try:
        response = requests.get(f"{API_URL}/health", timeout=2)
        if response.status_code == 200:
            st.success("✅ Backend Connected")
            st.caption(f"API: {API_URL}")
        else:
            st.warning("⚠️ Backend Issue")
    except Exception:
        st.error("❌ Backend Disconnected")
        st.caption("Make sure backend is running at localhost:8000")

    st.divider()

    st.markdown("### 📡 Data Sources")
    st.markdown("- USGS Earthquakes")
    st.markdown("- NOAA Hurricanes")
    st.markdown("- NWS Weather Data")

    st.divider()

    st.markdown("### ⏰ Update Schedule")
    st.markdown("**Every 7 days**")
    st.caption(f"Last update: {datetime.now().strftime('%Y-%m-%d')}")

if page == "🏠 Home":
    show_home()
elif page == "🗺️ Risk Map":
    map_page.show()
elif page == "💬 AI Assistant":
    chatbot_page.show()
